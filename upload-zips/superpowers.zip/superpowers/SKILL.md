---
name: superpowers
description: Engineering workflow guides - brainstorming, writing and executing plans, test-driven development, systematic debugging, code review, verification before completion, git worktrees, parallel/subagent work. Use for non-trivial coding tasks; read only the one guide that matches the task.
---

# Superpowers (bundled)

Router for 15 workflow guides. Read ONLY the guide(s) that match the current task - do not load all of them (saves tokens).

| Guide | Use when | File |
| ----- | -------- | ---- |
| `brainstorming` | You MUST use this before any creative work - creating features, building components, adding functionality, modifying behavior, or planning a | `references/brainstorming/GUIDE.md` |
| `diagnosing-superpowers` | a superpowers session went wrong and your human partner wants to know why — repeated work, ignored plans, stumbles, poor results, a skill th | `references/diagnosing-superpowers/GUIDE.md` |
| `dispatching-parallel-agents` | facing 2+ independent tasks that can be worked on without shared state or sequential dependencies | `references/dispatching-parallel-agents/GUIDE.md` |
| `executing-plans` | executing an implementation plan in the current session as the implementer yourself — your human partner chose inline execution, or no subag | `references/executing-plans/GUIDE.md` |
| `finishing-a-development-branch` | implementation is complete, all tests pass, and you need to decide how to integrate the work | `references/finishing-a-development-branch/GUIDE.md` |
| `receiving-code-review` | receiving code review feedback, before implementing suggestions, especially if feedback seems unclear or technically questionable - requires | `references/receiving-code-review/GUIDE.md` |
| `requesting-code-review` | completing tasks, implementing major features, or before merging to verify work meets requirements | `references/requesting-code-review/GUIDE.md` |
| `subagent-driven-development` | executing implementation plans with independent tasks in the current session | `references/subagent-driven-development/GUIDE.md` |
| `systematic-debugging` | encountering any bug, test failure, or unexpected behavior, before proposing fixes | `references/systematic-debugging/GUIDE.md` |
| `test-driven-development` | implementing any feature or bugfix, before writing implementation code | `references/test-driven-development/GUIDE.md` |
| `using-git-worktrees` | starting feature work that needs isolation from current workspace or before executing implementation plans - ensures an isolated workspace e | `references/using-git-worktrees/GUIDE.md` |
| `using-superpowers` | starting any conversation - establishes how to find and use skills, requiring skill invocation before ANY response including clarifying ques | `references/using-superpowers/GUIDE.md` |
| `verification-before-completion` | about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirmin | `references/verification-before-completion/GUIDE.md` |
| `writing-plans` | you have a spec or requirements for a multi-step task, before touching code | `references/writing-plans/GUIDE.md` |
| `writing-skills` | creating new skills, editing existing skills, or verifying skills work before deployment | `references/writing-skills/GUIDE.md` |

## How to use
1. Pick the single best-matching row. Open its `GUIDE.md` and follow it.
2. Guides may mention other skills by name (e.g. `superpowers:test-driven-development`). Here, open `references/<that-name>/GUIDE.md` instead of calling a Skill tool.
3. Guides may reference helper files (scripts, prompts) in their own folder; they sit next to `GUIDE.md`.
4. Skip guides for trivial tasks.
